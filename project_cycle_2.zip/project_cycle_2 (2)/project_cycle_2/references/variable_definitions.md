# Variable Definitions

## Behavior Variable

### SadOrHopeless
This variable measures whether a student reported feeling sad or hopeless.

For this project:
- Valid responses used in the analysis are code 1 and code 2 only.
- Code 1 is treated as success.
- Code 2 is treated as failure.
- Missing values are excluded from the analysis.

## Additional Variable Used for EDA

### WhatIsYourSex
This variable identifies the student's sex.

For the subgroup EDA:
- Code 1 = Male
- Code 2 = Female
- Only valid codes 1 and 2 are used in the subgroup comparison.