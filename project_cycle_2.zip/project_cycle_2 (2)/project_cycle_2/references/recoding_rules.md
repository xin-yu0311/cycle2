# Recoding Rules

## SadOrHopeless

Original coding used in the dataset:
- 1 = success
- 2 = failure

Binary recoding used in the analysis:
- 1 -> 1 (success)
- 2 -> 0 (failure)

Missing values are excluded from the analysis.

## Benchmark Value

For the one-sample proportion test:
- p0 = 0.30

## Additional EDA Recoding

### WhatIsYourSex
For subgroup comparison in EDA:
- 1 -> Male
- 2 -> Female