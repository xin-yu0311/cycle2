Project Cycle 2

#Group Information
Group Number: 10
Members:
113370209王心妤
113370214吳宗祐
113370236賴建佑

#Dataset
YRBS_2007.csv

#Selected Variables
- Continuous variable: HowTallAreYouWithoutShoesInMeters

#Benchmark Values
- Mean analysis: μ0 = 1.70 meters

#short project Question
Is the mean of HowTallAreYouWithoutShoesInMeters different from 1.70 meters?

#Final Conclusion
The average height of students is approximately 1.69 meters.
Statistical analysis suggests a significant difference from 1.70 meters, but the difference is very small and may not be practically meaningful.
